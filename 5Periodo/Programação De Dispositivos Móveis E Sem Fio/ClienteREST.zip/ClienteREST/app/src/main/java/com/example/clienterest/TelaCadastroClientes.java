package com.example.clienterest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Looper;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.example.clienterest.model.Cliente;
import com.google.gson.Gson;

import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class TelaCadastroClientes extends AppCompatActivity implements AdapterView.OnItemLongClickListener {


    Gson gson;
    EditText edNome, edCpf, edTelefone, edCep, edLogradouro, edNumero, edLocalidade, edUf, edBairro, edComplemento;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_cadastro_clientes);
        edNome = (EditText) findViewById(R.id.edNome);
        edCpf = (EditText) findViewById(R.id.edCpf);
        edTelefone = (EditText) findViewById(R.id.edTelefone);
        edCep = (EditText) findViewById(R.id.edCep);
        edLogradouro = (EditText) findViewById(R.id.edLogradouro);
        edNumero = (EditText) findViewById(R.id.edNumero);
        edLocalidade = (EditText) findViewById(R.id.edLocalidade);
        edUf = (EditText) findViewById(R.id.edUf);
        edBairro = (EditText) findViewById(R.id.edBairro);
        edComplemento = (EditText) findViewById(R.id.edComplemento);
    }

    public void visualizar(View view){
        Intent intent = new Intent(this, TelaVisualizarClientes.class);
        startActivity(intent);
    }
    public void inserir(View view) {
        String nome = edNome.getText().toString();
        String cpf = edCpf.getText().toString();
        String telefone = edTelefone.getText().toString();
        String cep = edCep.getText().toString();
        String logradouro = edLogradouro.getText().toString();
        String numero = edNumero.getText().toString();
        String localidade = edLocalidade.getText().toString();
        String uf = edUf.getText().toString();
        String bairro = edBairro.getText().toString();
        String complemento = edComplemento.getText().toString();
        Cliente c = new Cliente();
        c.setNome(nome);
        c.setCpf(cpf);
        c.setTelefone(telefone);
        c.setCep(cep);
        c.setLogradouro(logradouro);
        c.setNumero(numero);
        c.setLocalidade(localidade);
        c.setUf(uf);
        c.setBairro(bairro);
        c.setComplemento(complemento);
        final String json = gson.toJson(c);
        new Thread() {
            public void run() {
                Looper.prepare();
                try {
                    URL url = new URL("http://argo.td.utfpr.edu.br/clients/ws/cliente");
                    HttpURLConnection cnx = (HttpURLConnection) url.openConnection();
                    cnx.setRequestMethod("POST");
                    cnx.setRequestProperty("Content-Type", "application/json");
                    PrintWriter saida = new PrintWriter(cnx.getOutputStream());
                    saida.println(json);
                    saida.flush();
                    cnx.connect();
                    if (cnx.getResponseCode() == 201) {
                        Toast.makeText(getApplicationContext(),
                                "Cliente cadastrado com sucesso!",
                                Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(getApplicationContext(),
                                "Falha no cadastro do cliente.",
                                Toast.LENGTH_LONG).show();
                    }
                } catch (Throwable t) {
                    t.printStackTrace();
                }
                Looper.loop();
            }
        }.start();
    }


    @Override
    public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
        return true;
    }
}