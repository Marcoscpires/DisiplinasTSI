package com.example.listacomroom.banco;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.listacomroom.modelo.Produto;

import java.util.List;

@Dao
public interface ProdutoDAO {

    @Insert
    public long inserir(Produto p);

    @Delete
    public void remover(Produto p);

    @Update
    public void atualizar(Produto p);

    @Query("select * from produto where id_depto = :idDepto")
    public List<Produto> buscarPorDepartamento(long idDepto);

}
