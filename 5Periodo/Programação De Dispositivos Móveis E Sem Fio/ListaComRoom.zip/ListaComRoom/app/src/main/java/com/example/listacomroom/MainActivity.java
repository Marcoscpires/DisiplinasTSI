package com.example.listacomroom;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

import com.example.listacomroom.banco.Banco;
import com.example.listacomroom.banco.DepartamentoDAO;
import com.example.listacomroom.modelo.Departamento;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity
        implements AdapterView.OnItemLongClickListener {

    EditText edNome;
    ListView lwDeptos;
    ArrayAdapter adapter;
    Banco bd;
    DepartamentoDAO deptoDAO;
    List<Departamento> listaDeptos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edNome = (EditText) findViewById(R.id.edDepartamento);
        lwDeptos = (ListView) findViewById(R.id.departamentos);
        bd = Room.databaseBuilder( getApplicationContext(), Banco.class,
                "lista_compras").allowMainThreadQueries().build();
        deptoDAO = bd.getDeptoDAO();
        listarDeptos();
        adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_single_choice,
                        listaDeptos);
        lwDeptos.setAdapter( adapter );
        lwDeptos.setOnItemLongClickListener( this );
    }

    public void inserir( View v) {
        String nome = edNome.getText().toString();
        Departamento dp = new Departamento( nome );
        deptoDAO.inserir( dp );
        listarDeptos();
        adapter.notifyDataSetChanged();
        edNome.setText("");
    }

    public void listarDeptos() {
        if (listaDeptos == null) {
            listaDeptos = new ArrayList<>(200);
        } else {
            listaDeptos.clear();
        }
        List<Departamento> lst = deptoDAO.buscarTodos();
        listaDeptos.addAll(lst);
    }

    @Override
    public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
        Departamento dpto = listaDeptos.get(i);
        Intent it = new Intent( this, CadProdutos.class);
        it.putExtra("idDepto", dpto.getId());
        startActivity( it );
        return true;
    }
}