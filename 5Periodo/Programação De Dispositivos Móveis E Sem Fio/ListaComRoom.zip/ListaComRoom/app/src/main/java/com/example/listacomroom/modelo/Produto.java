package com.example.listacomroom.modelo;

import androidx.room.*;

import java.util.Objects;

@Entity
public class Produto {
    @PrimaryKey(autoGenerate = true)
    private long id;

    private String descricao;

    private double quantidade;

    private boolean comprado;

    @ColumnInfo(name="id_depto")
    private long idDepto;

    public Produto() { }

    @Ignore
    public Produto(String descricao, double quantidade, long idDepto) {
        this.descricao = descricao;
        this.quantidade = quantidade;
        this.idDepto = idDepto;
        this.comprado = false;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public double getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(double quantidade) {
        this.quantidade = quantidade;
    }

    public boolean isComprado() {
        return comprado;
    }

    public void setComprado(boolean comprado) {
        this.comprado = comprado;
    }

    public long getIdDepto() {
        return idDepto;
    }

    public void setIdDepto(long idDepto) {
        this.idDepto = idDepto;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Produto produto = (Produto) o;
        return id == produto.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    public String toString() {
        return descricao+"  "+quantidade+"  "+
                (comprado ? "S" : "N");
    }
}
