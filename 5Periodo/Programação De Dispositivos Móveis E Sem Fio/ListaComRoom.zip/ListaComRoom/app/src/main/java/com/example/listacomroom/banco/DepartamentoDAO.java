package com.example.listacomroom.banco;

import androidx.lifecycle.LiveData;
import androidx.room.*;

import com.example.listacomroom.modelo.Departamento;
import com.example.listacomroom.modelo.DeptoComProdutos;

import java.util.List;

@Dao
public interface DepartamentoDAO {

    @Insert
    public void inserir(Departamento dep);

    @Delete
    public void remover(Departamento dep);

    @Query("select * from departamento order by nome")
    List<Departamento> buscarTodos();

    @Transaction
    @Query("select * from departamento where id = :id")
    LiveData<DeptoComProdutos> buscarPorId(int id );

}
