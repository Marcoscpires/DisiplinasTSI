package com.example.clienterest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Looper;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.clienterest.model.Setor;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if (!InternerStatus.temConexao(this)) {
            Toast.makeText(this, "Não é possível usar o aplicativo sem conexão com a internet.", Toast.LENGTH_SHORT).show();
        }
    }

    public void clientes(View view){
        Intent intent = new Intent(this, TelaCadastroClientes.class);
        startActivity(intent);
    }

    public void pedidos(View view){
        Intent intent = new Intent(this, TelaPedidos.class);
        startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate( R.menu.menu_main, menu);
        return true;
    }

    public void clientes(MenuItem mi){
        Intent intent = new Intent(this, TelaCadastroClientes.class);
        startActivity(intent);
    }
    
    public void pedidos(MenuItem mi){
        Intent intent = new Intent(this, TelaPedidos.class);
        startActivity(intent);
    }
 }