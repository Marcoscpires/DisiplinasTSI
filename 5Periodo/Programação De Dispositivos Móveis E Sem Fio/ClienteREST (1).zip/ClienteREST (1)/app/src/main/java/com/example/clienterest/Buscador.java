package com.example.clienterest;

public interface Buscador {
}
