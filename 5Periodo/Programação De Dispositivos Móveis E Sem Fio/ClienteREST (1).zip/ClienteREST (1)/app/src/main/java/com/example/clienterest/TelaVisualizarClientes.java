package com.example.clienterest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Looper;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.clienterest.model.Cliente;
import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.stream.Collectors;

public class TelaVisualizarClientes extends AppCompatActivity implements AdapterView.OnItemLongClickListener,AdapterView.OnItemClickListener {

    ClienteAdapter adapter;
    public final int TELA_EDICAO = 3008;
    ListView lista;
    ArrayList<Cliente> clientes;
    private Cliente clienteSelecionado = null;
    int posicaoSelecionada = -1;

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        if(position == posicaoSelecionada){
            posicaoSelecionada = -1;
        } else {
            posicaoSelecionada = position;
        }
        adapter.notifyDataSetChanged();
    }

    class ClienteAdapter extends ArrayAdapter<Cliente>{
        public ClienteAdapter(Context ctx, ArrayList<Cliente> lista) {
            super(ctx, android.R.layout.simple_list_item_single_choice, lista);
        }

        @Override
        public View getView(int posicao, View reciclada, ViewGroup grupo) {
            if (reciclada == null) {
                reciclada = getLayoutInflater().inflate(R.layout.item_cliente,
                        null);
            }
            Cliente c = clientes.get( posicao );
            ((TextView) reciclada.findViewById(R.id.item_nome)).setText(""+c.getNome());
            ((TextView) reciclada.findViewById(R.id.item_cpf)).setText(""+c.getCpf());
            ((TextView) reciclada.findViewById(R.id.item_telefone)).setText(""+ c.getTelefone());

            if(posicao == posicaoSelecionada){
                reciclada.setBackgroundColor(Color.GRAY);
            }else {
                reciclada.setBackgroundColor(Color.TRANSPARENT);
            }
            return reciclada;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_visualizar_clientes);
        lista = ((ListView) findViewById(R.id.listaCliente));
        clientes = new ArrayList<>();
        adapter = new ClienteAdapter(this, clientes);
        lista.setAdapter(adapter);
        lista.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
        lista.setOnItemClickListener(this);
        lista.setOnItemLongClickListener(this);
        posicaoSelecionada = -1;
        listar();
    }

    @Override
    protected void onResume() {
        super.onResume();
        lista = ((ListView) findViewById(R.id.listaCliente));
        clientes = new ArrayList<>();
        adapter = new ClienteAdapter(this, clientes);
        lista.setAdapter(adapter);
        lista.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
        lista.setOnItemClickListener(this);
        lista.setOnItemLongClickListener(this);
        posicaoSelecionada = -1;
        listar();
    }

    public void listar(){
        Buscador buscador = new Buscador();
        buscador.execute();
    }
    class Buscador extends AsyncTask<String, Void, Cliente[]> implements com.example.clienterest.Buscador {
        @Override
        protected Cliente[] doInBackground(String... strings) {
            try {
                URL url = new URL("http://argo.td.utfpr.edu.br/clients/ws/cliente/");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.connect();
                if (conn.getResponseCode() == 200) {
                    BufferedReader reader = new BufferedReader(
                            new InputStreamReader(conn.getInputStream()));
                    StringBuilder sb = new StringBuilder();
                    String linha;
                    do {
                        linha = reader.readLine();
                        if (linha != null) {
                            sb.append(linha);
                        }
                    } while (linha != null);
                    String json = sb.toString();
                    Gson gson = new Gson();
                    Cliente[] clientesjson = gson.fromJson(json, Cliente[].class);

                    return clientesjson;
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return null;
        }
        @Override
        public void onPostExecute(Cliente[] clientesjson) {
            clientes = new ArrayList<>(Arrays.asList(clientesjson));
            lista = ((ListView) findViewById(R.id.listaCliente));
            adapter = new TelaVisualizarClientes.ClienteAdapter(TelaVisualizarClientes.this,clientes);
            lista.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
            lista.setAdapter(adapter);
            adapter.notifyDataSetChanged();
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate( R.menu.menu_clientes_visualizar, menu);
        return true;
    }
    public void cadastrar(MenuItem mi){
        Intent intent = new Intent(this, TelaCadastroClientes.class);
        startActivity(intent);
    }
    public void deletar(MenuItem mi){
        clienteSelecionado = clientes.get(posicaoSelecionada);
        String cpfDeletar = clienteSelecionado.getCpf();
        new Thread() {
            public void run() {
                Looper.prepare();
                try {
                    URL url = new URL("http://argo.td.utfpr.edu.br/clients/ws/cliente/"+cpfDeletar);
                    HttpURLConnection cnx = (HttpURLConnection) url.openConnection();
                    cnx.setRequestMethod("DELETE");
                    cnx.connect();

                    if(cnx.getResponseCode() > 399){
                        Toast.makeText(getApplicationContext(),
                                "Este Cliente tem pedidos em aberto apague-os antes de remover esse cliente.",
                                Toast.LENGTH_LONG).show();
                    } else if (cnx.getResponseCode() == 204) {
                        Toast.makeText(getApplicationContext(),
                                "Cliente Deletado!",
                                Toast.LENGTH_LONG).show();
                            //adapter.remove(clienteSelecionado);
                            clientes.remove(posicaoSelecionada);
                            posicaoSelecionada = -1;
                            adapter.notifyDataSetChanged();
                    } else {
                        Toast.makeText(getApplicationContext(),
                                "Falha.",
                                Toast.LENGTH_LONG).show();
                    }
                } catch (Throwable t) {
                    t.printStackTrace();
                }
                Looper.loop();
            }
        }.start();

    }
    public void editar(MenuItem mi){
        clienteSelecionado = clientes.get(posicaoSelecionada);
        Intent it = new Intent(TelaVisualizarClientes.this, TelaCadastroClientes.class);
        it.putExtra("cliente-editando", clienteSelecionado);
        startActivityForResult(it, TELA_EDICAO);
    }

    @Override
    public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
        return false;
    }
}