package com.example.clienterest;

import static androidx.constraintlayout.widget.ConstraintLayoutStates.TAG;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Looper;
import android.text.Editable;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.text.TextWatcher;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.Toast;

import com.example.clienterest.model.Cliente;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class TelaCadastroClientes extends AppCompatActivity implements AdapterView.OnItemLongClickListener {
    Gson gson;
    private EditText edNome, edCpf, edTelefone, edCep, edLogradouro, edNumero, edLocalidade, edUf, edBairro, edComplemento;
    private Boolean editando = false;
    Cliente cliEd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_cadastro_clientes);
        editando = false;
        edNome = (EditText) findViewById(R.id.edNome);
        edCpf = (EditText) findViewById(R.id.edCpf);
        edTelefone = (EditText) findViewById(R.id.edTelefone);
        edCep = (EditText) findViewById(R.id.edCep);
        edLogradouro = (EditText) findViewById(R.id.edLogradouro);
        edNumero = (EditText) findViewById(R.id.edNumero);
        edLocalidade = (EditText) findViewById(R.id.edLocalidade);
        edUf = (EditText) findViewById(R.id.edUf);
        edBairro = (EditText) findViewById(R.id.edBairro);
        edComplemento = (EditText) findViewById(R.id.edComplemento);
        gson = new GsonBuilder().create();
        Intent it = getIntent();
        if (it != null) {
            cliEd = (Cliente) it.getSerializableExtra("cliente-editando");
            if (cliEd != null) {
                editando = true;
                edNome.setText(cliEd.getNome());
                edCpf.setText(cliEd.getCpf());
                edTelefone.setText(cliEd.getTelefone());
                edCep.setText(cliEd.getCep());
                edLogradouro.setText(cliEd.getLogradouro());
                edNumero.setText(cliEd.getNumero());
                edLocalidade.setText(cliEd.getLocalidade());
                edUf.setText(cliEd.getUf());
                edBairro.setText(cliEd.getBairro());
                edComplemento.setText(cliEd.getComplemento());
            }
        }
        if(!editando){
            edCep.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                }
                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    atualizarEndereco(s.toString());
                }
                @Override
                public void afterTextChanged(Editable s) {
                }
            });
        }else{
            edCep.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                }
                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                }
                @Override
                public void afterTextChanged(Editable s) {
                    atualizarEndereco(s.toString());
                }
            });
        }
    }

    public void visualizar(View view){
        Intent intent = new Intent(this, TelaVisualizarClientes.class);
        startActivity(intent);
    }
    public void visualizar(MenuItem mi){
        Intent intent = new Intent(this, TelaVisualizarClientes.class);
        startActivity(intent);
    }

    public void voltar(MenuItem mi){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

   private void atualizarEndereco(String cep) {
        if(cep.length() >= 8) {
            String url = "https://viacep.com.br/ws/" + cep + "/json/";

            new ConsultaCEP().execute(url);
        }
   }
    private class ConsultaCEP extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... urls) {
            try {
                URL url = new URL(urls[0]);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");

                int responseCode = connection.getResponseCode();

                if (responseCode == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String line;

                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }

                    reader.close();

                    return response.toString();
                } else {
                    Log.e(TAG, "Erro na consulta do CEP. Código de resposta: " + responseCode);
                }
            } catch (IOException e) {
                Log.e(TAG, "Erro na consulta do CEP: " + e.getMessage());
            }

            return null;
        }

        @Override
        protected void onPostExecute(String response) {
            if (response != null) {
                try {
                    JSONObject json = new JSONObject(response);

                    String logradouro = json.getString("logradouro");
                    String bairro = json.getString("bairro");
                    String cidade = json.getString("localidade");
                    String uf = json.getString("uf");

                    edLogradouro.setText(logradouro);
                    edBairro.setText(bairro);
                    edLocalidade.setText(cidade);
                    edUf.setText(uf);

                } catch (JSONException e) {
                    Log.e(TAG, "Erro ao analisar resposta JSON: " + e.getMessage());
                }
            } else {
                Log.e(TAG, "Resposta do servidor nula");
            }
        }
    }

    public void inserir(){
        Cliente c = new Cliente();
        c.setNome(edNome.getText().toString());
        c.setCpf(edCpf.getText().toString());
        c.setTelefone(edTelefone.getText().toString());
        c.setCep(edCep.getText().toString());
        c.setLogradouro(edLogradouro.getText().toString());
        c.setNumero(edNumero.getText().toString());
        c.setLocalidade(edLocalidade.getText().toString());
        c.setUf(edUf.getText().toString());
        c.setBairro(edBairro.getText().toString());
        c.setComplemento(edComplemento.getText().toString());
        final String json = gson.toJson(c);
        new Thread() {
            public void run() {
                Looper.prepare();
                try {
                    URL url = new URL("http://argo.td.utfpr.edu.br/clients/ws/cliente");
                    HttpURLConnection cnx = (HttpURLConnection) url.openConnection();
                    cnx.setRequestMethod("POST");
                    cnx.setRequestProperty("Content-Type", "application/json");
                    PrintWriter saida = new PrintWriter(cnx.getOutputStream());
                    saida.println(json);
                    saida.flush();
                    cnx.connect();
                    if (cnx.getResponseCode() == 201) {
                        Toast.makeText(getApplicationContext(),
                                "Cliente cadastrado com sucesso!",
                                Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(getApplicationContext(),
                                "Falha no cadastro do cliente.",
                                Toast.LENGTH_LONG).show();
                    }
                } catch (Throwable t) {
                    t.printStackTrace();
                }
                Looper.loop();
            }
        }.start();
        edNome.setText("");
        edCpf.setText("");
        edTelefone.setText("");
        edCep.setText("");
        edLogradouro.setText("");
        edNumero.setText("");
        edLocalidade.setText("");
        edUf.setText("");
        edBairro.setText("");
        edComplemento.setText("");
    }

    public void editar(){
        cliEd.setNome(edNome.getText().toString());
        cliEd.setCpf(edCpf.getText().toString());
        cliEd.setTelefone(edTelefone.getText().toString());
        cliEd.setCep(edCep.getText().toString());
        cliEd.setLogradouro(edLogradouro.getText().toString());
        cliEd.setNumero(edNumero.getText().toString());
        cliEd.setLocalidade(edLocalidade.getText().toString());
        cliEd.setUf(edUf.getText().toString());
        cliEd.setBairro(edBairro.getText().toString());
        cliEd.setComplemento(edComplemento.getText().toString());
        final String json = gson.toJson(cliEd);
        new Thread() {
            public void run() {
                Looper.prepare();
                try {
                    URL url = new URL("http://argo.td.utfpr.edu.br/clients/ws/cliente/" + cliEd.getCpf());
                    HttpURLConnection cnx = (HttpURLConnection) url.openConnection();
                    cnx.setRequestMethod("PUT");
                    cnx.setRequestProperty("Content-Type", "application/json");
                    PrintWriter saida = new PrintWriter(cnx.getOutputStream());
                    saida.println(json);
                    saida.flush();
                    cnx.connect();
                    if (cnx.getResponseCode() == 204) {
                        Toast.makeText(getApplicationContext(),
                                "Cliente atualizado com sucesso!",
                                Toast.LENGTH_LONG).show();
                                finish();
                    } else {
                        Toast.makeText(getApplicationContext(),
                                "Falha ao atualizar o cliente.",
                                Toast.LENGTH_LONG).show();
                    }
                } catch (Throwable t) {
                    t.printStackTrace();
                }
                Looper.loop();
            }
        }.start();

    }
    public void confirmar(View view) {
        if(editando){
            editar();
        }else{
            inserir();
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate( R.menu.menu_clientes_cadastro, menu);
        return true;
    }



    @Override
    public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
        return true;
    }
}