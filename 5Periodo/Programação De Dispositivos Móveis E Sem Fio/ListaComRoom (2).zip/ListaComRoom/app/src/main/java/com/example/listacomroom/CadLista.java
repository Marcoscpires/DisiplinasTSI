package com.example.listacomroom;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

import com.example.listacomroom.banco.Banco;
import com.example.listacomroom.banco.ListaComprasDAO;
import com.example.listacomroom.modelo.ListaCompras;

import java.util.ArrayList;
import java.util.List;

public class CadLista extends AppCompatActivity
        implements AdapterView.OnItemLongClickListener {

    EditText edDescricao;
    Banco db;
    ListView lwListCompras;
    ArrayAdapter adapter;
    ListaComprasDAO listaComprasDAO;
    List<ListaCompras> listaComprasList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cad_lista);
        edDescricao = (EditText) findViewById(R.id.edDescricao);
        lwListCompras = (ListView) findViewById(R.id.listasCompras);
        db = Room.databaseBuilder( getApplicationContext(), Banco.class,
                "lista_compras").allowMainThreadQueries().build();
        listaComprasDAO = db.getListaComprasDAO();
        listarListaCompras();
        adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_single_choice,
                listaComprasList);
        lwListCompras.setAdapter(adapter);
        lwListCompras.setOnItemLongClickListener(this);
    }

    public void inserir(View v){
        String descricao = edDescricao.getText().toString();
        ListaCompras lc = new ListaCompras(descricao);
        listaComprasDAO.inserir(lc);
        listarListaCompras();
        adapter.notifyDataSetChanged();
        edDescricao.setText("");
    }

    public void listarListaCompras(){
        if(listaComprasList == null){
            listaComprasList = new ArrayList<>(200);
        } else {
            listaComprasList.clear();
        }
        List<ListaCompras> lst = listaComprasDAO.buscarTodos();
        listaComprasList.addAll(lst);
    }

    @Override
    public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
        return false;
    }
}