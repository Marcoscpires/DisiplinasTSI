package com.example.listacomroom.banco;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Transaction;

import com.example.listacomroom.modelo.ListaCompras;

import java.util.List;

@Dao
public interface ListaComprasDAO {

    @Insert
    public void inserir(ListaCompras lis);

    @Delete
    public void remover(ListaCompras lis);

    @Query("select * from listacompras order by descricao")
    List<ListaCompras> buscarTodos();

    // @Transaction
    // @Query("select * from listacompras where id = :id")
    // LiveData<> buscarPorId(int id );

}
