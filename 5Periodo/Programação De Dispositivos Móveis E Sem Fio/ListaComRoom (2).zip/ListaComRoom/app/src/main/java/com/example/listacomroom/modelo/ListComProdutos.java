package com.example.listacomroom.modelo;

import androidx.room.Embedded;
import androidx.room.Relation;

import java.util.List;

public class ListComProdutos {

    @Embedded
    ListaCompras listcomp;

    @Relation(
            parentColumn="id",
            entityColumn="id_lista"
    )
    public List<Produto> prods;

    public ListaCompras getListcomp() {
        return listcomp;
    }

    public void setListcomp(ListaCompras listcomp) {
        this.listcomp = listcomp;
    }

    public List<Produto> getProds() {
        return prods;
    }

    public void setProds(List<Produto> prods) {
        this.prods = prods;
    }
}
