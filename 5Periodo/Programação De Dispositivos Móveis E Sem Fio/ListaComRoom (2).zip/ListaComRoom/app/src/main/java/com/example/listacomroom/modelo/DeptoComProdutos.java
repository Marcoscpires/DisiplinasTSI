package com.example.listacomroom.modelo;

import androidx.room.*;

import java.util.List;

public class DeptoComProdutos {
    @Embedded
    Departamento depto;

    @Relation(
        parentColumn="id",
        entityColumn="id_depto"
    )
    public List<Produto> prods;

    public Departamento getDepto() {
        return depto;
    }

    public void setDepto(Departamento depto) {
        this.depto = depto;
    }

    public List<Produto> getProds() {
        return prods;
    }

    public void setProds(List<Produto> prods) {
        this.prods = prods;
    }
}
