package com.example.listacomroom.banco;

import androidx.room.*;

import com.example.listacomroom.modelo.Departamento;
import com.example.listacomroom.modelo.ListaCompras;
import com.example.listacomroom.modelo.Produto;

@Database( entities = { Departamento.class, Produto.class, ListaCompras.class },
           version=1, exportSchema = false)
public abstract class Banco extends RoomDatabase {
    public abstract DepartamentoDAO getDeptoDAO();
    public abstract ProdutoDAO getProdutoDAO();

    public abstract ListaComprasDAO getListaComprasDAO();
}
