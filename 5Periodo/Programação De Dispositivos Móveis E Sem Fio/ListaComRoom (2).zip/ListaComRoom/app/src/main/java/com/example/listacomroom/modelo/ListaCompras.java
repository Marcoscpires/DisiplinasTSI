package com.example.listacomroom.modelo;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.io.Serializable;

@Entity
public class ListaCompras implements Serializable {

    @PrimaryKey(autoGenerate = true)
    private long id;

    private String descricao;

    public ListaCompras(){}
    public ListaCompras(String descricao){
        this.descricao = descricao;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    @NonNull
    @Override
    public String toString() {return id+" "+descricao;}
}
