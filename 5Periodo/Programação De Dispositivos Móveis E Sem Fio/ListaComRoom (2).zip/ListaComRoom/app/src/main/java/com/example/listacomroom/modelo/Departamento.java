package com.example.listacomroom.modelo;

import androidx.room.*;

import java.io.Serializable;

@Entity
public class Departamento implements Serializable {

    @PrimaryKey( autoGenerate = true)
    private long id;

    private String nome;

    public Departamento() { }

    @Ignore
    public Departamento(String nome) {
        this.nome = nome;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String toString() { return nome; }
}
