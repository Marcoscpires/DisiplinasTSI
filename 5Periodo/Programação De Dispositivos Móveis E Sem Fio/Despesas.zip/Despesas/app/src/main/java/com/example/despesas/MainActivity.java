package com.example.despesas;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {
    public final int TELA_CONTAS = 1623;
    private ArrayList<Categorias> categorias;
    private EditText edCategoria;
    private ListView lista;
    private CategoriasAdapter adapter;
    private  Categorias categoriaSelecionada = null;
    int posicaoSelecionada = -1;

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        if(position == posicaoSelecionada){
            posicaoSelecionada = -1;
        } else {
            posicaoSelecionada = position;
        }
        adapter.notifyDataSetChanged();
    }
    class CategoriasAdapter extends ArrayAdapter<Categorias>{
        public CategoriasAdapter(Context ctx, ArrayList<Categorias> lista) {
            super(ctx, android.R.layout.simple_list_item_single_choice, lista);
        }

        @Override
        public View getView(int posicao, View reciclada, ViewGroup grupo) {
            if (reciclada == null) {
                reciclada = getLayoutInflater().inflate(R.layout.itens_categorias,
                        null);
            }
            Categorias c = categorias.get( posicao );
            ((TextView) reciclada.findViewById(R.id.item_categoria)).setText(""+c.getDescricao());
            ((TextView) reciclada.findViewById(R.id.item_quantidade)).setText(""+c.getContas().size());
            ((TextView) reciclada.findViewById(R.id.item_valor)).setText("R$ "+ c.getContas().stream().collect(Collectors.summingDouble(Conta::getValor)));

            if(posicao == posicaoSelecionada){
                reciclada.setBackgroundColor(Color.GRAY);
            }else {
                reciclada.setBackgroundColor(Color.TRANSPARENT);
            }
            return reciclada;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edCategoria = (EditText) findViewById(R.id.ed_categoria);
        lista = (ListView) findViewById(R.id.lista_categorias);
        adapter = new CategoriasAdapter(this, categorias);
        lista.setAdapter(adapter);
        lista.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
        lista.setOnItemClickListener(this);
        lista.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int pos, long id) {
                categoriaSelecionada = categorias.get(pos);
                Intent it = new Intent(MainActivity.this, TelaConta.class);
                it.putExtra("categoria_contas", categoriaSelecionada);
                startActivityForResult(it, TELA_CONTAS);
                return true;
            }
        });
        if (savedInstanceState != null) {
            adapter = new CategoriasAdapter(this, categorias);
            lista.setAdapter(adapter);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate( R.menu.menu_principal, menu);
        return true;
    }
    public boolean editar(MenuItem mi){
        int pos = lista.getCheckedItemPosition();
        if (pos >= 0) {
            categoriaSelecionada = categorias.get(pos);
            Intent it = new Intent(MainActivity.this, TelaConta.class);
            it.putExtra("categoria_contas", categoriaSelecionada);
            startActivityForResult(it, TELA_CONTAS);
            posicaoSelecionada = -1;
            return true;

        } else {
            Toast.makeText(this,R.string.selecione_editar,
                    Toast.LENGTH_SHORT).show();
            return false;
        }
    }
    public void excluir(MenuItem mi){
        int pos = lista.getCheckedItemPosition();
        if (pos >= 0) {
            Categorias c = categorias.get(pos);
            AlertDialog.Builder bld = new AlertDialog.Builder(this);
            bld.setTitle(R.string.confirmacao);
            bld.setMessage( getText(R.string.deseja_remover) + " " +
                    c.getDescricao() + " " + getText(R.string.contas_da_categoria));
            bld.setPositiveButton(R.string.sim, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    categorias.remove( pos );
                    adapter.notifyDataSetChanged();
                }
            });
            bld.setCancelable( false );
            bld.setNegativeButton(R.string.nao, null);
            bld.show();
        } else {
            Toast.makeText(this,R.string.selecione_excluir,
                    Toast.LENGTH_SHORT).show();
        }
    }
    public void sair(MenuItem mi){finish();}


    public void adicionar(View view){
        Categorias c = new Categorias();
        if(edCategoria.getText().toString().isEmpty()){
            Toast.makeText(this, R.string.categoria_vazia, Toast.LENGTH_SHORT).show();
        } else {
            c.setDescricao(edCategoria.getText().toString());
            c.setContas(new ArrayList<>());
            categorias.add(c);
            adapter.notifyDataSetChanged();
            edCategoria.setText("");
        }
    }
    @Override
    public void onActivityResult(int codigo, int resultado, Intent dados) {
        super.onActivityResult(codigo, resultado, dados);
        if (codigo == TELA_CONTAS) {
            Categorias categoriaContas = (Categorias) dados.getSerializableExtra("categoria_contas");
            categorias.set(categorias.indexOf(categoriaContas),categoriaContas);
        }
        posicaoSelecionada = -1;
        adapter.notifyDataSetChanged();


    }

}