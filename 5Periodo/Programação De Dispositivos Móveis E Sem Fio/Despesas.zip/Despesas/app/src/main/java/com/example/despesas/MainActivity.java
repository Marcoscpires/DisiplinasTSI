package com.example.despesas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemLongClickListener {
    public final int TELA_CONTAS = 1623;
    private ArrayList<Categorias> categorias;
    private EditText edCategoria;
    private ListView lista;
    private CategoriasAdapter adapter;
    private  Categorias categoriaSelecionada = null;
    private double valor = 0;


    class CategoriasAdapter extends ArrayAdapter<Categorias>{
        public CategoriasAdapter(Context ctx, ArrayList<Categorias> lista) {
            super(ctx, android.R.layout.simple_list_item_1, lista);
        }

        @Override
        public View getView(int posicao, View reciclada, ViewGroup grupo) {
            if (reciclada == null) {
                reciclada = getLayoutInflater().inflate(R.layout.itens_categorias,
                        null);
            }
            Categorias c = categorias.get( posicao );
            ((TextView) reciclada.findViewById(R.id.item_categoria)).setText(""+c.getDescricao());
            ((TextView) reciclada.findViewById(R.id.item_quantidade)).setText(""+c.getContas().size());
            ((TextView) reciclada.findViewById(R.id.item_valor)).setText("R$ "+ c.getContas().stream().);
            return reciclada;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edCategoria = (EditText) findViewById(R.id.ed_categoria);
        lista = (ListView) findViewById(R.id.lista_categorias);
        categorias = new ArrayList<>();
        adapter = new CategoriasAdapter(this, categorias);
        lista.setAdapter(adapter);
        lista.setOnItemLongClickListener( this );
    }

    public void adicionar(View view){
        Categorias c = new Categorias();
        c.setDescricao(edCategoria.getText().toString());
        c.setContas(new ArrayList<>());
        categorias.add(c);
        adapter.notifyDataSetChanged();
        edCategoria.setText("");
    }
    @Override
    public void onActivityResult(int codigo, int resultado, Intent dados) {
        super.onActivityResult(codigo, resultado, dados);
        if (codigo == TELA_CONTAS) {
            Categorias categoriaContas = (Categorias) dados.getSerializableExtra("categoria_contas");
            categorias.set(categorias.indexOf(categoriaContas),categoriaContas);
        }
        adapter.notifyDataSetChanged();

    }

    @Override
    public boolean onItemLongClick(AdapterView<?> adapterView,View view, int pos, long id){
        categoriaSelecionada = categorias.get(pos);
        Intent it = new Intent(MainActivity.this, TelaConta.class);
        it.putExtra("categoria_contas", categoriaSelecionada);
        startActivityForResult(it, TELA_CONTAS);
        return true;
    }

}