package com.example.despesas;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class TelaConta extends AppCompatActivity {

    ListView lista;
    ArrayList<Conta> contas;
    EditText edDescicao, edValor, edVencimento;
    ContasAdapter adapter;
    Date dataVencimento;
    Categorias ed;
    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");


    class ContasAdapter extends ArrayAdapter<Conta> {
        public ContasAdapter(Context ctx, ArrayList<Conta> lista) {
            super(ctx, android.R.layout.simple_list_item_1, lista);
        }
        @Override
        public View getView(int posicao, View reciclada, ViewGroup grupo) {
            if (reciclada == null) {
                reciclada = getLayoutInflater().inflate(R.layout.itens_conta,
                        null);
            }
            Conta c = contas.get( posicao );
            ((TextView) reciclada.findViewById(R.id.item_conta)).setText(""+c.getDescricao());
            ((TextView) reciclada.findViewById(R.id.item_vencimento)).setText(sdf.format(c.getVencimento()));
            ((TextView) reciclada.findViewById(R.id.item_valor)).setText("R$ "+ c.getValor());
            return reciclada;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_contas);
        edDescicao = (EditText) findViewById(R.id.ed_descricao);
        edValor = (EditText) findViewById(R.id.ed_valor);
        edVencimento = (EditText) findViewById(R.id.ed_vecimento);
        Intent it = getIntent();
        if (it != null) {
            ed = (Categorias) it.getSerializableExtra("categoria_contas");
            if (ed != null) {
                ((TextView) findViewById(R.id.categoria)).setText(ed.getDescricao());
                contas = ed.getContas();
            }
        }
        lista = (ListView) findViewById(R.id.lista_contas);
        adapter = new ContasAdapter(this,contas);
        lista.setAdapter(adapter);
    }

    public void adicionar_conta(View view){
        Conta conta = new Conta();
        conta.setDescricao((edDescicao).getText().toString());
        conta.setValor(Double.parseDouble(edValor.getText().toString()));
        conta.setVencimento(dataVencimento);
        conta.setCategoria(ed);
        contas.add(conta);
        ed.setContas(contas);
        adapter.notifyDataSetChanged();
        edDescicao.setText("");
        edValor.setText("");
        edVencimento.setText("");
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(TelaConta.this, MainActivity.class);
        intent.putExtra("categoria_contas", ed);
        setResult(RESULT_OK, intent);
        finish();
        super.onBackPressed();

    }

    public void selecionarData(View v){
        DatePickerDialog dlgData = new DatePickerDialog(this);
        dlgData.setOnDateSetListener(new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int ano, int mes, int dia) {
                Calendar cal = Calendar.getInstance();
                cal.set(Calendar.YEAR, ano);
                cal.set(Calendar.MONTH, mes);
                cal.set(Calendar.DAY_OF_MONTH, dia);
                dataVencimento = cal.getTime();
                edVencimento.setText(sdf.format(dataVencimento));
            }
        });
        dlgData.show();
    }
}