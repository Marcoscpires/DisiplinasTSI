package com.example.despesas;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class TelaConta extends AppCompatActivity implements AdapterView.OnItemClickListener{

    ListView lista;
    ArrayList<Conta> contas;
    EditText edDescicao, edValor, edVencimento;
    ContasAdapter adapter;
    Conta contaSelecionada;
    Date dataVencimento;
    Categorias ed;
    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
    int posicaoSelecionada = -1;


    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        if (position == posicaoSelecionada) {
            posicaoSelecionada = -1;
        } else {
            posicaoSelecionada = position;
        }
        adapter.notifyDataSetChanged();
    }

    class ContasAdapter extends ArrayAdapter<Conta> {
        public ContasAdapter(Context ctx, ArrayList<Conta> lista) {
            super(ctx, android.R.layout.simple_list_item_single_choice, lista);
        }
        @Override
        public View getView(int posicao, View reciclada, ViewGroup grupo) {
            if (reciclada == null) {
                reciclada = getLayoutInflater().inflate(R.layout.itens_conta,
                        null);
            }
            Conta c = contas.get( posicao );
            ((TextView) reciclada.findViewById(R.id.item_conta)).setText(""+c.getDescricao());
            ((TextView) reciclada.findViewById(R.id.item_vencimento)).setText(sdf.format(c.getVencimento()));
            ((TextView) reciclada.findViewById(R.id.item_valor)).setText("R$ "+ c.getValor());

            if(posicao == posicaoSelecionada){
                reciclada.setBackgroundColor(Color.GRAY);
            }else {
                reciclada.setBackgroundColor(Color.TRANSPARENT);
            }

            return reciclada;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_contas);
        edDescicao = (EditText) findViewById(R.id.ed_descricao);
        edValor = (EditText) findViewById(R.id.ed_valor);
        edVencimento = (EditText) findViewById(R.id.ed_vecimento);
        Intent it = getIntent();
        if (it != null) {
            ed = (Categorias) it.getSerializableExtra("categoria_contas");
            if (ed != null) {
                ((TextView) findViewById(R.id.categoria)).setText(ed.getDescricao());
                contas = ed.getContas();
            }
        }
        lista = (ListView) findViewById(R.id.lista_contas);
        adapter = new ContasAdapter(this,contas);
        lista.setAdapter(adapter);
        lista.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
        lista.setOnItemClickListener( this );
    }

    public void adicionar_conta(View view){
        Conta conta = new Conta();
        if ( contaSelecionada != null){
            conta = contaSelecionada;
        }
        if(edDescicao.getText().toString().isEmpty()||edValor.getText().toString().isEmpty()||edVencimento.getText().toString().isEmpty()){
            Toast.makeText(this,R.string.preencha_campos,
                    Toast.LENGTH_SHORT).show();
        } else {
            conta.setDescricao((edDescicao).getText().toString());
            conta.setValor(Double.parseDouble(edValor.getText().toString()));
            conta.setVencimento(dataVencimento);
            conta.setCategoria(ed);

            if( contaSelecionada == null) {
                contas.add(conta);
            } else {
                contaSelecionada = null;
            }
            ed.setContas(contas);
            edDescicao.setText("");
            edValor.setText("");
            edVencimento.setText("");
            posicaoSelecionada = -1;
            adapter.notifyDataSetChanged();
        }

    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(TelaConta.this, MainActivity.class);
        intent.putExtra("categoria_contas", ed);
        setResult(RESULT_OK, intent);
        finish();
        super.onBackPressed();

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate( R.menu.menu_contas, menu);
        return true;
    }

    public void editar(MenuItem mi){
        int pos = lista.getCheckedItemPosition();
        if (pos >= 0) {
            contaSelecionada = contas.get(pos);
            ((EditText) findViewById(R.id.ed_descricao)).setText( contaSelecionada.getDescricao() );
            ((EditText) findViewById(R.id.ed_valor)).setText(String.valueOf(contaSelecionada.getValor()) );
            ((EditText) findViewById(R.id.ed_vecimento)).setText(sdf.format(contaSelecionada.getVencimento()));

        } else {
            Toast.makeText(this,R.string.selecione_editar,
                    Toast.LENGTH_SHORT).show();
        }
    }
    public void voltar(MenuItem mi){
        Intent intent = new Intent(TelaConta.this, MainActivity.class);
        intent.putExtra("categoria_contas", ed);
        setResult(RESULT_OK, intent);
        finish();
    }
    public void excluir(MenuItem mi){
        int pos = lista.getCheckedItemPosition();
        if (pos >= 0) {
            Conta c = contas.get(pos);
            AlertDialog.Builder bld = new AlertDialog.Builder(this);
            bld.setTitle(R.string.confirmacao);
            bld.setMessage( R.string.deseja_remover +
                    c.getDescricao()+R.string.contas_da_categoria);
            bld.setPositiveButton(R.string.sim, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    contas.remove( pos );
                    adapter.notifyDataSetChanged();
                }
            });
            bld.setCancelable( false );
            bld.setNegativeButton(R.string.nao, null);
            bld.show();
        } else {
            Toast.makeText(this,R.string.selecione_excluir,
                    Toast.LENGTH_SHORT).show();
        }
    }

    public void selecionarData(View v){
        DatePickerDialog dlgData = new DatePickerDialog(this);
        dlgData.setOnDateSetListener(new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int ano, int mes, int dia) {
                Calendar cal = Calendar.getInstance();
                cal.set(Calendar.YEAR, ano);
                cal.set(Calendar.MONTH, mes);
                cal.set(Calendar.DAY_OF_MONTH, dia);
                dataVencimento = cal.getTime();
                edVencimento.setText(sdf.format(dataVencimento));
            }
        });
        dlgData.show();
    }
}