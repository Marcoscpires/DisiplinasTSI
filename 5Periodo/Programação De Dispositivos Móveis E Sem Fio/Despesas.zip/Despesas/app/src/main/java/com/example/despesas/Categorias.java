package com.example.despesas;

import androidx.annotation.Nullable;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Objects;

public class Categorias implements Serializable {
        private String descricao;
        private ArrayList<Conta> contas;

        public String getDescricao() {
            return descricao;
        }

        public void setDescricao(String descricao) {
            this.descricao = descricao;
        }

        public ArrayList<Conta> getContas() {
            return contas;
        }

        public void setContas(ArrayList<Conta> contas) {
            this.contas = contas;
        }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Categorias that = (Categorias) o;
        return descricao.equals(that.descricao);
    }

    @Override
    public int hashCode() {
        return Objects.hash(descricao);
    }
}

