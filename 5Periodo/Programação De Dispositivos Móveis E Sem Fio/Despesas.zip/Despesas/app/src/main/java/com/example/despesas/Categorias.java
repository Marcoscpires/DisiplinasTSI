package com.example.despesas;

import java.io.Serializable;
import java.util.ArrayList;

public class Categorias implements Serializable {
        private String descricao;
        private ArrayList<Conta> contas;

        public String getDescricao() {
            return descricao;
        }

        public void setDescricao(String descricao) {
            this.descricao = descricao;
        }

        public ArrayList<Conta> getContas() {
            return contas;
        }

        public void setContas(ArrayList<Conta> contas) {
            this.contas = contas;
        }
}

